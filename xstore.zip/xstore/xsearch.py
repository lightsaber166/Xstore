import os
import tkinter as tk
from tkinter import ttk, filedialog

def list_files_in_folder(folder_path):
    files = []
    for root, dirs, filenames in os.walk(folder_path):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            files.append(file_path)
    return files

def browse_folder():
    folder_path = filedialog.askdirectory(title="Select Directory to Index")
    if folder_path:
        folder_path_entry.delete(0, tk.END)
        folder_path_entry.insert(0, folder_path)
        index_files(folder_path)

def index_files(folder_path):
    files = list_files_in_folder(folder_path)
    result_listbox.delete(0, tk.END)
    for file in files:
        result_listbox.insert(tk.END, file)

# Create the main window
root = tk.Tk()
root.title("File Indexer")

# Create and configure widgets
frame = ttk.Frame(root, padding=10)
frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))
frame.columnconfigure(0, weight=1)
frame.rowconfigure(0, weight=1)

label = ttk.Label(frame, text="Select the folder to index:")
label.grid(column=0, row=0, sticky=tk.W)

folder_path_entry = ttk.Entry(frame)
folder_path_entry.grid(column=0, row=1, sticky=(tk.W, tk.E))

browse_button = ttk.Button(frame, text="Browse", command=browse_folder)
browse_button.grid(column=1, row=1, sticky=tk.W)

index_button = ttk.Button(frame, text="Index Folder", command=lambda: index_files(folder_path_entry.get()))
index_button.grid(column=0, row=2, columnspan=2, sticky=tk.W)

result_listbox = tk.Listbox(frame)
result_listbox.grid(column=0, row=3, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))
result_listbox.configure(yscrollcommand=result_listbox.yview)

scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=result_listbox.yview)
scrollbar.grid(column=2, row=3, sticky=(tk.N, tk.S))
result_listbox.configure(yscrollcommand=scrollbar.set)

# Start the GUI main loop
root.mainloop()
