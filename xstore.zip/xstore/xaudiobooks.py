import os
import tkinter as tk
from tkinter import ttk
import pyttsx3

def list_txt_files_in_folder(folder_path):
    txt_files = []
    for root, dirs, filenames in os.walk(folder_path):
        for filename in filenames:
            if filename.endswith('.txt'):
                file_path = os.path.join(root, filename)
                txt_files.append(file_path)
    return txt_files

def index_txt_files():
    folder_path = 'audiobooks'
    txt_files = list_txt_files_in_folder(folder_path)
    txt_files_listbox.delete(0, tk.END)
    for file in txt_files:
        txt_files_listbox.insert(tk.END, file)

def read_selected_file():
    selected_file = txt_files_listbox.get(tk.ACTIVE)
    if selected_file:
        with open(selected_file, 'r', encoding='utf-8') as file:
            content = file.read()
            text_to_speech(content)

def text_to_speech(text):
    engine = pyttsx3.init()
    engine.setProperty('rate', 150)  # Adjust speech rate (words per minute)
    engine.say(text)
    engine.runAndWait()

# Create the main window
root = tk.Tk()
root.title("Audiobook Reader")

# Create and configure widgets
frame = ttk.Frame(root, padding=10)
frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))
frame.columnconfigure(0, weight=1)
frame.rowconfigure(0, weight=1)

txt_files_listbox = tk.Listbox(frame)
txt_files_listbox.grid(column=0, row=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))
txt_files_listbox.configure(yscrollcommand=txt_files_listbox.yview)

scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=txt_files_listbox.yview)
scrollbar.grid(column=2, row=0, sticky=(tk.N, tk.S))
txt_files_listbox.configure(yscrollcommand=scrollbar.set)

read_button = ttk.Button(frame, text="Read Selected Audiobook", command=read_selected_file)
read_button.grid(column=0, row=1, columnspan=2, sticky=tk.W)

# Automatically index files in the 'audiobooks' directory
index_txt_files()

# Start the GUI main loop
root.mainloop()
