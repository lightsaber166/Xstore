import tkinter as tk
import subprocess

# Define a list of applications as lists with [app name, app path]
applications = [
    ['File Indexer', 'xsearch.py'],
    ['Audio Book Reader', 'xaudiobooks.py'],
    ['json and yaml converter', 'xjson2yaml.py'],
    ['Note', 'xnote.py']
]

# Create the main window
root = tk.Tk()
root.title("xstore")
root.geometry('500x500')
# Function to launch an application
def launch_app(app_info):
    try:
        subprocess.Popen(app_info[1], shell=True)
    except Exception as e:
        messagebox.showerror("Error", f"Error launching '{app_info[0]}': {e}")

# Create buttons for each application in a grid
for i, app in enumerate(applications):
    button = tk.Button(root, text=app[0], command=lambda app_info=app: launch_app(app_info))
    button.grid(row=i // 3, column=i % 3, padx=10, pady=10)

# Start the GUI main loop
root.mainloop()
