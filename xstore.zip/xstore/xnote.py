import tkinter as tk
from tkinter import ttk, messagebox

def save_note():
    note_title = title_entry.get()
    note_content = content_text.get("1.0", "end-1c")

    if not note_title or not note_content:
        messagebox.showwarning("Warning", "Please enter both a title and content for the note.")
    else:
        with open("notes.txt", "a") as file:
            file.write(f"Title: {note_title}\n")
            file.write(f"Content:\n{note_content}\n")
            file.write("-" * 40 + "\n")
        clear_fields()
        messagebox.showinfo("Note Saved", "Your note has been saved successfully.")

def clear_fields():
    title_entry.delete(0, tk.END)
    content_text.delete("1.0", tk.END)

# Create the main window
root = tk.Tk()
root.title("Notes App")

# Create and configure widgets
frame = ttk.Frame(root, padding=10)
frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))
frame.columnconfigure(0, weight=1)
frame.columnconfigure(1, weight=1)
frame.rowconfigure(0, weight=1)
frame.rowconfigure(1, weight=1)

title_label = ttk.Label(frame, text="Title:")
title_label.grid(column=0, row=0, sticky=tk.W)

title_entry = ttk.Entry(frame)
title_entry.grid(column=1, row=0, sticky=(tk.W, tk.E))

content_label = ttk.Label(frame, text="Content:")
content_label.grid(column=0, row=1, sticky=tk.W)

content_text = tk.Text(frame, wrap=tk.WORD, width=40, height=10)
content_text.grid(column=1, row=1, sticky=(tk.W, tk.E))

save_button = ttk.Button(frame, text="Save Note", command=save_note)
save_button.grid(column=0, row=2, columnspan=2)

clear_button = ttk.Button(frame, text="Clear Fields", command=clear_fields)
clear_button.grid(column=0, row=3, columnspan=2)

# Start the GUI main loop
root.mainloop()
