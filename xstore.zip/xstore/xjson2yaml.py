import json
import yaml
import tkinter as tk
from tkinter import ttk, filedialog

def json_to_yaml():
    json_data = input_text.get("1.0", tk.END)
    try:
        parsed_data = json.loads(json_data)
        yaml_data = yaml.dump(parsed_data, default_flow_style=False)
        output_text.delete("1.0", tk.END)
        output_text.insert("1.0", yaml_data)
    except Exception as e:
        output_text.delete("1.0", tk.END)
        output_text.insert("1.0", f"Error converting JSON to YAML:\n{str(e)}")

def yaml_to_json():
    yaml_data = input_text.get("1.0", tk.END)
    try:
        parsed_data = yaml.load(yaml_data, Loader=yaml.FullLoader)
        json_data = json.dumps(parsed_data, indent=4)
        output_text.delete("1.0", tk.END)
        output_text.insert("1.0", json_data)
    except Exception as e:
        output_text.delete("1.0", tk.END)
        output_text.insert("1.0", f"Error converting YAML to JSON:\n{str(e)}")

def open_file():
    file_path = filedialog.askopenfilename(title="Select a JSON or YAML file", filetypes=(("JSON files", "*.json"), ("YAML files", "*.yaml *.yml")))
    if file_path:
        with open(file_path, "r") as file:
            input_data = file.read()
        input_text.delete("1.0", tk.END)
        input_text.insert("1.0", input_data)

def save_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=(("JSON files", "*.json"), ("YAML files", "*.yaml *.yml")))
    if file_path:
        output_data = output_text.get("1.0", tk.END)
        with open(file_path, "w") as file:
            file.write(output_data)

# Create the main window
root = tk.Tk()
root.title("JSON ↔ YAML Converter")

# Create and configure widgets
frame = ttk.Frame(root, padding=10)
frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))
frame.columnconfigure(0, weight=1)
frame.rowconfigure(0, weight=1)

input_label = ttk.Label(frame, text="Input JSON or YAML:")
input_label.grid(column=0, row=0, sticky=tk.W)

input_text = tk.Text(frame, wrap=tk.WORD, width=40, height=10)
input_text.grid(column=0, row=1)

output_label = ttk.Label(frame, text="Output:")
output_label.grid(column=0, row=2, sticky=tk.W)

output_text = tk.Text(frame, wrap=tk.WORD, width=40, height=10)
output_text.grid(column=0, row=3)

convert_button_frame = ttk.Frame(frame)
convert_button_frame.grid(column=0, row=4, pady=10)

json_to_yaml_button = ttk.Button(convert_button_frame, text="JSON to YAML", command=json_to_yaml)
json_to_yaml_button.grid(column=0, row=0, padx=5)

yaml_to_json_button = ttk.Button(convert_button_frame, text="YAML to JSON", command=yaml_to_json)
yaml_to_json_button.grid(column=1, row=0, padx=5)

open_button = ttk.Button(frame, text="Open File", command=open_file)
open_button.grid(column=0, row=5, pady=10)

save_button = ttk.Button(frame, text="Save File", command=save_file)
save_button.grid(column=0, row=6)

# Start the GUI main loop
root.mainloop()
